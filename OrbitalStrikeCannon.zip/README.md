# Orbital Strike Cannon 1.1.0 — Paper 1.21.11

Plugin source project for Minecraft Java Edition Paper 1.21.11.

## Fitur
- `/orbital`: memberi Fishing Rod khusus Orbital Strike Cannon.
- Klik kanan dengan rod khusus untuk menandai target dan memanggil TNT dari atas.
- TNT memakai ledakan vanilla normal dan dapat merusak blok.
- Cooldown, jeda serangan, jumlah TNT, sebaran, tinggi spawn, fuse, dan yield bisa diatur di `config.yml`.
- `/orbitaltrade`: membuka GUI trading kustom mirip menu trading Villager.
- Trading default: 8 Emerald + 2 TNT untuk 1 Orbital Strike Cannon.
- Permission `orbital.use` (default OP), `orbital.trade` (default semua pemain).

## Persyaratan
- Minecraft Java Edition Paper 1.21.11
- Java 21
- Maven 3.9+ (disarankan)

## Build
1. Ekstrak ZIP ke folder.
2. Buka terminal di folder yang berisi `pom.xml`.
3. Jalankan:
   ```bash
   mvn clean package
   ```
4. Setelah build berhasil, file JAR akan ada di:
   `target/OrbitalStrikeCannon-1.1.0.jar`
5. Salin JAR ke folder `plugins/` server Paper.
6. Restart server, lalu periksa `/plugins` dan console.

## Penggunaan
- `/orbital`
- Pegang rod tersebut dan klik kanan ke arah blok untuk memanggil serangan.
- `/orbitaltrade`

## Kustomisasi
Edit `plugins/OrbitalStrikeCannon/config.yml`, kemudian restart server.

## Catatan
- Source ini ditargetkan ke Paper API `1.21.11-R0.1-SNAPSHOT`. Jika repositori Paper belum menerbitkan artefak tersebut di mirror yang dipakai, periksa versi API yang tersedia di repositori Paper dan sesuaikan properti `paper-api` di `pom.xml`.
- TNT sengaja menggunakan perilaku ledakan vanilla dan dapat merusak blok. Uji di dunia cadangan sebelum memasang ke server utama.
- Trading dibuat sebagai GUI kustom, bukan profesi Villager sungguhan.

## Build otomatis lewat GitHub Actions (HP juga bisa)
1. Buat repository baru di GitHub.
2. Upload semua isi folder proyek ini ke repository (termasuk folder `.github/workflows/build.yml`), lalu commit ke branch `main`.
3. Buka tab **Actions** di repository. Jika diminta, aktifkan GitHub Actions.
4. Tunggu workflow **Build Orbital Strike Cannon** selesai dengan tanda hijau.
5. Buka run yang terbaru, scroll ke bagian **Artifacts**, lalu unduh `OrbitalStrikeCannon-Paper-1.21.11`.
6. Ekstrak artifact hasil build; file di dalamnya adalah `OrbitalStrikeCannon-1.1.0.jar`.
7. Upload file `.jar` itu ke folder `plugins/` di panel SkyMC, lalu restart server.

Workflow ini membangun JAR dan menyimpannya sebagai GitHub Actions artifact. Ia tidak mengunggah plugin otomatis ke SkyMC.
