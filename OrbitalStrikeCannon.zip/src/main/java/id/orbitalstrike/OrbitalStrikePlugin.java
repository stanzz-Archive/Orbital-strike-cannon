package id.orbitalstrike;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class OrbitalStrikePlugin extends JavaPlugin implements Listener {
    private NamespacedKey orbitalRodKey;
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    private static final String TRADE_TITLE = ChatColor.DARK_PURPLE + "Orbital Trading";
    private static final int TRADE_BUTTON_SLOT = 22;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        orbitalRodKey = new NamespacedKey(this, "orbital_rod");
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("OrbitalStrikeCannon 1.1.0 enabled.");
    }

    @Override
    public void onDisable() {
        cooldowns.clear();
    }

    private ItemStack createOrbitalRod() {
        ItemStack rod = new ItemStack(Material.FISHING_ROD);
        ItemMeta meta = rod.getItemMeta();
        meta.setDisplayName(ChatColor.LIGHT_PURPLE + "" + ChatColor.BOLD + "Orbital Strike Cannon");
        meta.setLore(List.of(
            ChatColor.GRAY + "Klik kanan untuk memanggil serangan orbital.",
            ChatColor.GRAY + "Arahkan pandangan ke blok target.",
            ChatColor.YELLOW + "Cooldown: " + getConfig().getInt("strike.cooldown-seconds", 8) + " detik"
        ));
        meta.getPersistentDataContainer().set(orbitalRodKey, PersistentDataType.BYTE, (byte) 1);
        rod.setItemMeta(meta);
        return rod;
    }

    private boolean isOrbitalRod(ItemStack item) {
        if (item == null || item.getType() != Material.FISHING_ROD || !item.hasItemMeta()) {
            return false;
        }
        Byte tag = item.getItemMeta().getPersistentDataContainer()
            .get(orbitalRodKey, PersistentDataType.BYTE);
        return tag != null && tag == (byte) 1;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("orbital")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Command ini hanya dapat digunakan oleh pemain.");
                return true;
            }
            ItemStack rod = createOrbitalRod();
            Map<Integer, ItemStack> overflow = player.getInventory().addItem(rod);
            overflow.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
            player.sendMessage(ChatColor.LIGHT_PURPLE + "Orbital Strike Cannon diberikan!");
            return true;
        }

        if (command.getName().equalsIgnoreCase("orbitaltrade")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Command ini hanya dapat digunakan oleh pemain.");
                return true;
            }
            openTradeMenu(player);
            return true;
        }
        return false;
    }

    @EventHandler
    public void onRodUse(PlayerInteractEvent event) {
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }

        Player player = event.getPlayer();
        ItemStack handItem = event.getItem();
        if (!isOrbitalRod(handItem)) {
            return;
        }

        event.setCancelled(true);
        long now = System.currentTimeMillis();
        long cooldownMs = Math.max(0, getConfig().getLong("strike.cooldown-seconds", 8)) * 1000L;
        long lastUse = cooldowns.getOrDefault(player.getUniqueId(), 0L);
        long remaining = cooldownMs - (now - lastUse);
        if (remaining > 0) {
            player.sendMessage(ChatColor.RED + "Orbital Cannon cooldown: " + ((remaining + 999) / 1000) + " detik.");
            return;
        }

        Location eye = player.getEyeLocation();
        RayTraceResult ray = player.getWorld().rayTraceBlocks(
            eye, eye.getDirection(), 100.0, FluidCollisionMode.NEVER, true
        );

        Location target;
        if (ray != null && ray.getHitPosition() != null) {
            target = ray.getHitPosition().toLocation(player.getWorld());
        } else {
            target = eye.clone().add(eye.getDirection().multiply(25));
        }

        cooldowns.put(player.getUniqueId(), now);
        World world = player.getWorld();
        world.playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 0.7f);
        world.spawnParticle(Particle.END_ROD, target.clone().add(0, 1, 0), 24, 0.4, 0.5, 0.4, 0.02);
        player.sendMessage(ChatColor.GOLD + "Target orbital terkunci! TNT akan jatuh sebentar lagi.");

        Location finalTarget = target.clone();
        long delayTicks = Math.max(1, getConfig().getLong("strike.delay-ticks", 40));
        Bukkit.getScheduler().runTaskLater(this, () -> spawnStrike(finalTarget), delayTicks);
    }

    private void spawnStrike(Location target) {
        World world = target.getWorld();
        if (world == null) {
            return;
        }

        int chunkX = target.getBlockX() >> 4;
        int chunkZ = target.getBlockZ() >> 4;
        if (!world.isChunkLoaded(chunkX, chunkZ)) {
            return;
        }

        int count = Math.max(1, Math.min(20, getConfig().getInt("strike.tnt-count", 3)));
        double spread = Math.max(0, getConfig().getDouble("strike.tnt-spread", 2.0));
        int height = Math.max(5, getConfig().getInt("strike.tnt-spawn-height", 24));
        int fuseTicks = Math.max(1, getConfig().getInt("strike.tnt-fuse-ticks", 50));
        float yield = (float) Math.max(0.0, Math.min(20.0, getConfig().getDouble("strike.tnt-yield", 4.0)));

        for (int i = 0; i < count; i++) {
            double dx = (Math.random() * 2.0 - 1.0) * spread;
            double dz = (Math.random() * 2.0 - 1.0) * spread;
            Location spawn = target.clone().add(dx, height + (i * 2), dz);
            TNTPrimed tnt = (TNTPrimed) world.spawnEntity(spawn, EntityType.TNT);
            tnt.setFuseTicks(fuseTicks);
            tnt.setVelocity(new Vector(0, -0.35, 0));
            tnt.setIsIncendiary(false);
            tnt.setYield(yield);
        }
        world.playSound(target, Sound.ENTITY_WITHER_SPAWN, 1.0f, 1.3f);
    }

    private void openTradeMenu(Player player) {
        Inventory inventory = Bukkit.createInventory(null, 27, TRADE_TITLE);

        int emeraldCost = Math.max(1, Math.min(64, getConfig().getInt("trade.emerald-cost", 8)));
        int tntCost = Math.max(1, Math.min(64, getConfig().getInt("trade.tnt-cost", 2)));

        inventory.setItem(11, namedItem(Material.EMERALD, emeraldCost,
            ChatColor.GREEN + "Biaya: " + emeraldCost + " Emerald"));
        inventory.setItem(13, namedItem(Material.TNT, tntCost,
            ChatColor.RED + "Biaya: " + tntCost + " TNT"));
        inventory.setItem(15, createOrbitalRod());

        ItemStack arrow = namedItem(Material.LIME_STAINED_GLASS_PANE, 1,
            ChatColor.GREEN + "" + ChatColor.BOLD + "KLIK UNTUK TRADE");
        ItemMeta arrowMeta = arrow.getItemMeta();
        arrowMeta.setLore(List.of(
            ChatColor.GRAY + "Tukar item di atas untuk hadiah.",
            ChatColor.GRAY + "Hadiah: Orbital Strike Cannon"
        ));
        arrow.setItemMeta(arrowMeta);
        inventory.setItem(TRADE_BUTTON_SLOT, arrow);

        player.openInventory(inventory);
    }

    private ItemStack namedItem(Material material, int amount, String name) {
        ItemStack item = new ItemStack(material, amount);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void onTradeInventoryClick(InventoryClickEvent event) {
        if (!TRADE_TITLE.equals(event.getView().getTitle())) {
            return;
        }
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (event.getRawSlot() != TRADE_BUTTON_SLOT) {
            return;
        }

        int emeraldCost = Math.max(1, Math.min(64, getConfig().getInt("trade.emerald-cost", 8)));
        int tntCost = Math.max(1, Math.min(64, getConfig().getInt("trade.tnt-cost", 2)));
        int outputAmount = Math.max(1, Math.min(64, getConfig().getInt("trade.output-amount", 1)));

        if (countItem(player, Material.EMERALD) < emeraldCost ||
            countItem(player, Material.TNT) < tntCost) {
            player.sendMessage(ChatColor.RED + "Emerald atau TNT kamu belum cukup untuk trade.");
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0f, 1.0f);
            return;
        }

        removeItems(player, Material.EMERALD, emeraldCost);
        removeItems(player, Material.TNT, tntCost);

        for (int i = 0; i < outputAmount; i++) {
            Map<Integer, ItemStack> overflow = player.getInventory().addItem(createOrbitalRod());
            overflow.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
        }

        player.sendMessage(ChatColor.GREEN + "Trade berhasil! Orbital Strike Cannon didapatkan.");
        player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_YES, 1.0f, 1.0f);
        player.closeInventory();
    }

    @EventHandler
    public void onTradeInventoryDrag(InventoryDragEvent event) {
        if (TRADE_TITLE.equals(event.getView().getTitle())) {
            event.setCancelled(true);
        }
    }

    private int countItem(Player player, Material material) {
        int total = 0;
        for (ItemStack item : player.getInventory().getStorageContents()) {
            if (item != null && item.getType() == material) {
                total += item.getAmount();
            }
        }
        return total;
    }

    private void removeItems(Player player, Material material, int amount) {
        int remaining = amount;
        for (ItemStack item : player.getInventory().getStorageContents()) {
            if (item == null || item.getType() != material) {
                continue;
            }
            int take = Math.min(remaining, item.getAmount());
            item.setAmount(item.getAmount() - take);
            remaining -= take;
            if (remaining <= 0) {
                break;
            }
        }
        player.updateInventory();
    }
}
